# LocalLead AI CRM Lite — iOS App Project

This is a native SwiftUI iOS app project for **LocalLead AI**, designed for iPhone 15 Pro.

## What it does
- Dashboard with lead counts and conversion rate
- Lead CRM with status tracking
- Add/edit/delete leads
- Today follow-up reminders
- WhatsApp/IG message templates
- Weekly report copy function
- Local storage using UserDefaults

## How to install on your iPhone
1. Download and unzip this folder on a Mac.
2. Open `LocalLeadAI.xcodeproj` in Xcode.
3. Connect your iPhone 15 Pro by cable or Wi-Fi.
4. In Xcode, select your iPhone as the run destination.
5. Go to **Signing & Capabilities** and choose your Apple ID team.
6. Press **Run**.

## Important
I cannot provide a one-tap installable iPhone app file here because iOS apps must be signed by Apple/Xcode or distributed through TestFlight/App Store.

For quickest testing without Xcode, use the included web/PWA version separately.
