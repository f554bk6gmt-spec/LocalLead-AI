import SwiftUI

@main
struct LocalLeadAIApp: App {
    @StateObject private var store = LeadStore()

    var body: some Scene {
        WindowGroup {
            MainTabView()
                .environmentObject(store)
        }
    }
}
