import Foundation

struct Lead: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var createdAt: Date = Date()
    var name: String
    var phone: String
    var source: LeadSource
    var interest: String
    var levelOrType: String
    var preferredTime: String
    var status: LeadStatus
    var nextFollowUp: Date
    var lastContacted: Date?
    var assignedTo: String
    var valueHKD: Double
    var notes: String
}

enum LeadSource: String, CaseIterable, Identifiable, Codable {
    case whatsapp = "WhatsApp"
    case instagram = "Instagram"
    case facebook = "Facebook"
    case website = "Website/Form"
    case referral = "Referral"
    case walkIn = "Walk-in"

    var id: String { rawValue }
}

enum LeadStatus: String, CaseIterable, Identifiable, Codable {
    case newLead = "新查詢"
    case replied = "已回覆"
    case trialBooked = "已約試堂/預約"
    case trialAttended = "已出席"
    case enrolled = "已報名/成交"
    case noReply = "未回覆"
    case lost = "放棄"

    var id: String { rawValue }

    var colorName: String {
        switch self {
        case .newLead: return "blue"
        case .replied: return "purple"
        case .trialBooked: return "orange"
        case .trialAttended: return "teal"
        case .enrolled: return "green"
        case .noReply: return "red"
        case .lost: return "gray"
        }
    }
}

struct MessageTemplate: Identifiable {
    let id = UUID()
    let title: String
    let category: String
    let body: String
}
