import Foundation
import SwiftUI

final class LeadStore: ObservableObject {
    @Published var leads: [Lead] = [] {
        didSet { save() }
    }

    private let storageKey = "localleadai.leads.v1"

    init() {
        load()
        if leads.isEmpty { leads = Self.sampleLeads }
    }

    func add(_ lead: Lead) {
        leads.insert(lead, at: 0)
    }

    func delete(at offsets: IndexSet) {
        leads.remove(atOffsets: offsets)
    }

    func update(_ lead: Lead) {
        guard let index = leads.firstIndex(where: { $0.id == lead.id }) else { return }
        leads[index] = lead
    }

    var todayFollowUps: [Lead] {
        let start = Calendar.current.startOfDay(for: Date())
        return leads.filter { lead in
            lead.nextFollowUp <= Calendar.current.date(byAdding: .day, value: 1, to: start)! &&
            lead.status != .enrolled && lead.status != .lost
        }.sorted { $0.nextFollowUp < $1.nextFollowUp }
    }

    var overdueLeads: [Lead] {
        let start = Calendar.current.startOfDay(for: Date())
        return leads.filter { lead in
            lead.nextFollowUp < start && lead.status != .enrolled && lead.status != .lost
        }
    }

    var conversionRate: Double {
        guard !leads.isEmpty else { return 0 }
        let won = leads.filter { $0.status == .enrolled }.count
        return Double(won) / Double(leads.count)
    }

    var potentialValue: Double {
        leads.filter { $0.status != .lost }.reduce(0) { $0 + $1.valueHKD }
    }

    func weeklyReportText() -> String {
        let total = leads.count
        let new = leads.filter { $0.status == .newLead }.count
        let booked = leads.filter { $0.status == .trialBooked }.count
        let enrolled = leads.filter { $0.status == .enrolled }.count
        let noReply = leads.filter { $0.status == .noReply }.count
        let overdue = overdueLeads.count
        let conversion = Int((conversionRate * 100).rounded())

        return """
        LocalLead AI 每週查詢報告

        總查詢：\(total)
        新查詢：\(new)
        已約試堂/預約：\(booked)
        已報名/成交：\(enrolled)
        未回覆：\(noReply)
        逾期未跟進：\(overdue)
        轉化率：約 \(conversion)%

        本週建議：
        1. 優先跟進所有逾期未回覆客戶。
        2. 對已回覆但未預約的客戶發送 24 小時 follow-up。
        3. 對已出席試堂/服務的客戶於 48 小時內跟進報名/下次預約。
        """
    }

    private func save() {
        do {
            let data = try JSONEncoder().encode(leads)
            UserDefaults.standard.set(data, forKey: storageKey)
        } catch {
            print("Save failed: \(error)")
        }
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey) else { return }
        do {
            leads = try JSONDecoder().decode([Lead].self, from: data)
        } catch {
            leads = []
        }
    }

    static var sampleLeads: [Lead] {
        [
            Lead(name: "陳太", phone: "9123 4567", source: .whatsapp, interest: "中二英文試堂", levelOrType: "中二", preferredTime: "星期六下午", status: .newLead, nextFollowUp: Date(), lastContacted: nil, assignedTo: "Miss Wong", valueHKD: 1800, notes: "想改善 writing"),
            Lead(name: "李先生", phone: "9876 1234", source: .instagram, interest: "小五數學", levelOrType: "小五", preferredTime: "平日 6pm", status: .trialBooked, nextFollowUp: Calendar.current.date(byAdding: .day, value: 1, to: Date())!, lastContacted: Date(), assignedTo: "Admin", valueHKD: 1600, notes: "已約本週六試堂"),
            Lead(name: "王小姐", phone: "6999 8888", source: .facebook, interest: "DSE Econ", levelOrType: "中五", preferredTime: "週末", status: .replied, nextFollowUp: Calendar.current.date(byAdding: .day, value: -1, to: Date())!, lastContacted: Calendar.current.date(byAdding: .day, value: -2, to: Date()), assignedTo: "Mr Chan", valueHKD: 2400, notes: "等家長確認時間")
        ]
    }
}
