import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView {
            DashboardView()
                .tabItem { Label("Dashboard", systemImage: "chart.bar.fill") }

            LeadsView()
                .tabItem { Label("Leads", systemImage: "person.3.fill") }

            TemplatesView()
                .tabItem { Label("Templates", systemImage: "message.fill") }

            ReportView()
                .tabItem { Label("Report", systemImage: "doc.text.fill") }
        }
        .tint(.blue)
    }
}

struct DashboardView: View {
    @EnvironmentObject var store: LeadStore

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    HeroCard()

                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                        MetricCard(title: "總查詢", value: "\(store.leads.count)", icon: "tray.full.fill", tint: .blue)
                        MetricCard(title: "今日跟進", value: "\(store.todayFollowUps.count)", icon: "bell.fill", tint: .orange)
                        MetricCard(title: "已成交", value: "\(store.leads.filter{$0.status == .enrolled}.count)", icon: "checkmark.seal.fill", tint: .green)
                        MetricCard(title: "轉化率", value: "\(Int((store.conversionRate * 100).rounded()))%", icon: "chart.line.uptrend.xyaxis", tint: .purple)
                    }

                    SectionTitle("今日需要跟進")
                    if store.todayFollowUps.isEmpty {
                        EmptyState(text: "暫時沒有今日需要跟進的客戶。")
                    } else {
                        ForEach(store.todayFollowUps.prefix(5)) { lead in
                            LeadMiniRow(lead: lead)
                        }
                    }

                    SectionTitle("逾期提醒")
                    Text("\(store.overdueLeads.count) 個查詢已過跟進日期。建議今日優先處理，避免漏客。")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(.red.opacity(0.08), in: RoundedRectangle(cornerRadius: 16))
                }
                .padding()
            }
            .navigationTitle("LocalLead AI")
        }
    }
}

struct HeroCard: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("查詢跟進系統")
                .font(.title2.bold())
            Text("將 WhatsApp / IG 查詢整理成清晰跟進流程，減少漏客，提高試堂、預約及成交機會。")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            HStack {
                Label("AI 模板", systemImage: "sparkles")
                Label("Follow-up", systemImage: "bell")
                Label("CRM", systemImage: "tablecells")
            }
            .font(.caption.bold())
            .foregroundStyle(.blue)
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LinearGradient(colors: [.blue.opacity(0.16), .cyan.opacity(0.10)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 22))
    }
}

struct MetricCard: View {
    let title: String
    let value: String
    let icon: String
    let tint: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: icon).foregroundStyle(tint).font(.title3)
            Text(value).font(.title.bold())
            Text(title).font(.caption).foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18))
    }
}

struct LeadsView: View {
    @EnvironmentObject var store: LeadStore
    @State private var showingAddLead = false
    @State private var searchText = ""

    var filtered: [Lead] {
        if searchText.isEmpty { return store.leads }
        return store.leads.filter { $0.name.localizedCaseInsensitiveContains(searchText) || $0.interest.localizedCaseInsensitiveContains(searchText) || $0.phone.localizedCaseInsensitiveContains(searchText) }
    }

    var body: some View {
        NavigationStack {
            List {
                ForEach(filtered) { lead in
                    NavigationLink(destination: LeadDetailView(lead: lead)) {
                        LeadRowView(lead: lead)
                    }
                }
                .onDelete(perform: store.delete)
            }
            .searchable(text: $searchText, prompt: "搜尋姓名 / 電話 / 服務")
            .navigationTitle("Leads")
            .toolbar {
                Button(action: { showingAddLead = true }) {
                    Image(systemName: "plus.circle.fill")
                }
            }
            .sheet(isPresented: $showingAddLead) {
                AddLeadView()
            }
        }
    }
}

struct LeadDetailView: View {
    @EnvironmentObject var store: LeadStore
    @Environment(\.dismiss) private var dismiss
    @State var lead: Lead

    var body: some View {
        Form {
            Section("客戶資料") {
                TextField("姓名", text: $lead.name)
                TextField("WhatsApp", text: $lead.phone)
                Picker("來源", selection: $lead.source) {
                    ForEach(LeadSource.allCases) { Text($0.rawValue).tag($0) }
                }
                TextField("查詢內容", text: $lead.interest)
                TextField("年級 / 類型", text: $lead.levelOrType)
                TextField("偏好時間", text: $lead.preferredTime)
            }

            Section("跟進") {
                Picker("狀態", selection: $lead.status) {
                    ForEach(LeadStatus.allCases) { Text($0.rawValue).tag($0) }
                }
                DatePicker("下次跟進", selection: $lead.nextFollowUp, displayedComponents: [.date, .hourAndMinute])
                TextField("負責人", text: $lead.assignedTo)
                TextField("潛在價值 HK$", value: $lead.valueHKD, format: .number)
            }

            Section("備註") {
                TextEditor(text: $lead.notes).frame(minHeight: 120)
            }

            Section {
                Button("儲存") {
                    store.update(lead)
                    dismiss()
                }
                .font(.headline)
            }
        }
        .navigationTitle(lead.name)
    }
}

struct AddLeadView: View {
    @EnvironmentObject var store: LeadStore
    @Environment(\.dismiss) private var dismiss

    @State private var name = ""
    @State private var phone = ""
    @State private var source: LeadSource = .whatsapp
    @State private var interest = ""
    @State private var levelOrType = ""
    @State private var preferredTime = ""
    @State private var nextFollowUp = Date()
    @State private var assignedTo = ""
    @State private var valueHKD: Double = 0
    @State private var notes = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("新查詢") {
                    TextField("姓名", text: $name)
                    TextField("WhatsApp", text: $phone)
                        .keyboardType(.phonePad)
                    Picker("來源", selection: $source) {
                        ForEach(LeadSource.allCases) { Text($0.rawValue).tag($0) }
                    }
                    TextField("查詢內容", text: $interest)
                    TextField("年級 / 類型", text: $levelOrType)
                    TextField("偏好時間", text: $preferredTime)
                }

                Section("跟進") {
                    DatePicker("下次跟進", selection: $nextFollowUp, displayedComponents: [.date, .hourAndMinute])
                    TextField("負責人", text: $assignedTo)
                    TextField("潛在價值 HK$", value: $valueHKD, format: .number)
                }

                Section("備註") {
                    TextEditor(text: $notes).frame(minHeight: 100)
                }
            }
            .navigationTitle("新增 Lead")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("新增") {
                        let newLead = Lead(name: name, phone: phone, source: source, interest: interest, levelOrType: levelOrType, preferredTime: preferredTime, status: .newLead, nextFollowUp: nextFollowUp, assignedTo: assignedTo, valueHKD: valueHKD, notes: notes)
                        store.add(newLead)
                        dismiss()
                    }
                    .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
    }
}

struct TemplatesView: View {
    let templates: [MessageTemplate] = [
        MessageTemplate(title: "新查詢回覆", category: "補習社", body: "你好，多謝查詢 😊 想幫你安排最合適嘅課程 / 試堂，麻煩你提供學生年級、想補科目同偏好時間，我哋會盡快幫你安排。"),
        MessageTemplate(title: "24 小時跟進", category: "補習社", body: "你好，想跟進返課程查詢。我哋今個星期仲有試堂時段，可以幫你預留一個位。你想平日定週末比較方便？"),
        MessageTemplate(title: "試堂前提醒", category: "補習社", body: "提提你，明日有試堂安排，到時見 😊 地址係：[地址]。如需要改時間，可以提前 WhatsApp 我哋。"),
        MessageTemplate(title: "試堂後報名跟進", category: "補習社", body: "多謝今日嚟試堂。老師初步建議可以先集中改善 [重點]。如果想報名，我哋可以幫你安排下星期開始上堂。"),
        MessageTemplate(title: "美容問價回覆", category: "美容 / Nail", body: "你好，可以呀。想幫你報準啲價，可以 send 你想做嘅款式 / 服務同想約日期時間俾我哋，我哋會盡快回覆可預約時段。"),
        MessageTemplate(title: "車房報價資料收集", category: "Auto", body: "你好，可以幫你報價。麻煩你 send 車款、年份、需要處理嘅問題相片 / 輪呔尺寸，同埋想今日定預約其他日子。")
    ]

    var body: some View {
        NavigationStack {
            List(templates) { template in
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text(template.title).font(.headline)
                        Spacer()
                        Text(template.category).font(.caption).foregroundStyle(.secondary)
                    }
                    Text(template.body).font(.subheadline).foregroundStyle(.secondary)
                    Button("Copy") {
                        UIPasteboard.general.string = template.body
                    }
                    .font(.caption.bold())
                }
                .padding(.vertical, 6)
            }
            .navigationTitle("Message Templates")
        }
    }
}

struct ReportView: View {
    @EnvironmentObject var store: LeadStore
    @State private var copied = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("每週 Lead Report")
                        .font(.title2.bold())
                    Text(store.weeklyReportText())
                        .font(.body)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18))

                    Button {
                        UIPasteboard.general.string = store.weeklyReportText()
                        copied = true
                    } label: {
                        Label(copied ? "已複製" : "複製報告", systemImage: copied ? "checkmark" : "doc.on.doc")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding()
            }
            .navigationTitle("Report")
        }
    }
}

struct LeadRowView: View {
    let lead: Lead
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(lead.name).font(.headline)
                Spacer()
                StatusBadge(status: lead.status)
            }
            Text("\(lead.interest) • \(lead.source.rawValue)")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Text("下次跟進：\(lead.nextFollowUp.formatted(date: .abbreviated, time: .shortened))")
                .font(.caption)
                .foregroundStyle(lead.nextFollowUp < Date() && lead.status != .enrolled && lead.status != .lost ? .red : .secondary)
        }
        .padding(.vertical, 4)
    }
}

struct LeadMiniRow: View {
    let lead: Lead
    var body: some View {
        HStack(spacing: 12) {
            Circle().fill(.blue.opacity(0.12)).frame(width: 42, height: 42).overlay(Image(systemName: "person.fill").foregroundStyle(.blue))
            VStack(alignment: .leading) {
                Text(lead.name).font(.headline)
                Text(lead.interest).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            StatusBadge(status: lead.status)
        }
        .padding()
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
    }
}

struct StatusBadge: View {
    let status: LeadStatus
    var body: some View {
        Text(status.rawValue)
            .font(.caption.bold())
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(color.opacity(0.12), in: Capsule())
            .foregroundStyle(color)
    }
    var color: Color {
        switch status {
        case .newLead: return .blue
        case .replied: return .purple
        case .trialBooked: return .orange
        case .trialAttended: return .teal
        case .enrolled: return .green
        case .noReply: return .red
        case .lost: return .gray
        }
    }
}

struct SectionTitle: View {
    let text: String
    init(_ text: String) { self.text = text }
    var body: some View { Text(text).font(.headline).padding(.top, 6) }
}

struct EmptyState: View {
    let text: String
    var body: some View {
        Text(text)
            .foregroundStyle(.secondary)
            .padding()
            .frame(maxWidth: .infinity)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
    }
}
