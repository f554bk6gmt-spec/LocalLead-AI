# LocalLead AI — PWA Web Version

This is a mobile-first browser/PWA version of LocalLead AI.

## Run locally on desktop
Open `index.html` in a browser.

## Install on iPhone home screen
iPhone home-screen install works best from HTTPS hosting.

1. Upload this whole folder to Netlify, Vercel, GitHub Pages, or another HTTPS host.
2. Open the hosted URL in Safari on iPhone.
3. Tap Share → Add to Home Screen.

## Notes
- Data is saved locally in the browser with localStorage.
- Use Settings → Export JSON to back up data.
- No backend or external API is required.
